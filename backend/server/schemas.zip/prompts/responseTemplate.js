const responseTemplate = {
  overallVerdict: {
    label: "",
    explanation: "",
  },

  credibility: {
    score: 0,
    label: "",
    explanation: "",
  },

  bias: {
    score: 0,
    label: "",
    explanation: "",
    detectedBiases: [
      {
        type: "",
        severity: "",
        confidenceScore: 0,
        explanation: "",
        evidence: [
          {
            text: "",
            startIndex: null,
            endIndex: null,
          },
        ],
      },
    ],
  },

  emotionalManipulation: {
    score: 0,
    label: "",
    explanation: "",
    detectedTechniques: [
      {
        technique: "",
        severity: "",
        confidenceScore: 0,
        explanation: "",
        evidence: [
          {
            text: "",
            startIndex: null,
            endIndex: null,
          },
        ],
      },
    ],
  },

  claims: [
    {
      text: "",
      confidenceScore: 0,
      needsVerification: true,
      importance: "",
      category: "",
      evidence: [
        {
          text: "",
          startIndex: null,
          endIndex: null,
        },
      ],
    },
  ],

  riskIndicators: [
    {
      title: "",
      severity: "",
      confidenceScore: 0,
      explanation: "",
      recommendation: "",
      evidence: [
        {
          text: "",
          startIndex: null,
          endIndex: null,
        },
      ],
    },
  ],

  summary: "",

  recommendations: [],
};

export default responseTemplate;
