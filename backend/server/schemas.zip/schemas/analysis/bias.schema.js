import mongoose from "mongoose";
import evidenceSchema from "../shared/evidence.schema.js";

const detectedBiasSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      required: true,
      trim: true,
    },

    severity: {
      type: String,
      required: true,
      enum: ["Negligible", "Low", "Moderate", "High", "Critical"],
    },

    confidenceScore: {
      type: Number,
      required: true,
      min: 0,
      max: 100,
    },

    explanation: {
      type: String,
      required: true,
      trim: true,
    },

    examples: [evidenceSchema],
  },
  {
    _id: false,
  },
);

const biasSchema = new mongoose.Schema(
  {
    score: {
      type: Number,
      required: true,
      min: 0,
      max: 100,
    },

    label: {
      type: String,
      required: true,
      enum: [
        "Unbiased",
        "Slightly Biased",
        "Moderately Biased",
        "Highly Biased",
        "Extremely Biased",
      ],
    },

    detectedBiases: [detectedBiasSchema],

    explanation: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    _id: false,
  },
);

export default biasSchema;
