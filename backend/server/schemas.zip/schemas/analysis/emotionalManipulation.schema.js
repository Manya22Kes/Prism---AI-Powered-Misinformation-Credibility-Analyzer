import mongoose from "mongoose";
import evidenceSchema from "../shared/evidence.schema.js";

const detectedTechniqueSchema = new mongoose.Schema(
  {
    technique: {
      type: String,
      required: true,
      trim: true,
    },

    severity: {
      type: String,
      required: true,
      enum: ["Negligible", "Low", "Moderate", "High", "Critical"],
    },

    confidenceScore: {
      type: Number,
      required: true,
      min: 0,
      max: 100,
    },

    explanation: {
      type: String,
      required: true,
      trim: true,
    },

    evidence: [evidenceSchema],
  },
  {
    _id: false,
  },
);

const emotionalManipulationSchema = new mongoose.Schema(
  {
    score: {
      type: Number,
      required: true,
      min: 0,
      max: 100,
    },

    label: {
      type: String,
      required: true,
      enum: [
        "Not Manipulative",
        "Slightly Manipulative",
        "Moderately Manipulative",
        "Highly Manipulative",
        "Extremely Manipulative",
      ],
    },

    detectedTechniques: [detectedTechniqueSchema],

    explanation: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    _id: false,
  },
);

export default emotionalManipulationSchema;
