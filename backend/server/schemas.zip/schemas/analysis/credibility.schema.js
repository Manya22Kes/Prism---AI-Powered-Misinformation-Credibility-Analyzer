import mongoose from "mongoose";

const credibilitySchema = new mongoose.Schema(
  {
    score: {
      type: Number,
      required: true,
      min: 0,
      max: 100,
    },

    label: {
      type: String,
      required: true,
      enum: [
        "Unreliable",
        "Questionable",
        "Moderate",
        "Reliable",
        "Highly Reliable",
      ],
    },

    explanation: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    _id: false,
  },
);

export default credibilitySchema;
