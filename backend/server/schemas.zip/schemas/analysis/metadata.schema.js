import mongoose from "mongoose";

const metadataSchema = new mongoose.Schema(
  {
    provider: {
      type: String,
      required: true,
      trim: true,
    },

    model: {
      type: String,
      required: true,
      trim: true,
    },

    processingDuration: {
      type: Number,
      required: true,
      min: 0,
    },

    analysisVersion: {
      type: Number,
      default: 1,
      min: 1,
    },

    fileType: {
      type: String,
      default: null,
      trim: true,
    },
  },
  {
    _id: false,
  },
);

export default metadataSchema;
