import mongoose from "mongoose";
import evidenceSchema from "../shared/evidence.schema.js";

const claimSchema = new mongoose.Schema(
  {
    text: {
      type: String,
      required: true,
      trim: true,
    },

    confidenceScore: {
      type: Number,
      required: true,
      min: 0,
      max: 100,
    },

    needsVerification: {
      type: Boolean,
      required: true,
      default: true,
    },

    importance: {
      type: String,
      required: true,
      enum: ["Minor", "Moderate", "Major", "Critical"],
    },

    category: {
      type: String,
      required: true,
      enum: [
        "Health",
        "Politics",
        "Science",
        "Finance",
        "Technology",
        "Environment",
        "Crime",
        "Education",
        "Business",
        "Sports",
        "Entertainment",
        "Other",
      ],
    },

    evidence: [evidenceSchema],
  },
  {
    _id: false,
  },
);

export default claimSchema;
